package com.zybooks.inventoryappfaithsheppard.ui.inventory;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;
    private String alert;
    private String description;

    public InventoryItem(int id, String name, int quantity, String alert, String description) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.alert = alert;
        this.description = description;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getAlert() {
        return alert;
    }

    public String getDescription() {
        return description;
    }
}
