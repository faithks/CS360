package com.zybooks.inventoryappfaithsheppard.data;

import android.content.Context;

import com.zybooks.inventoryappfaithsheppard.data.Result;
import com.zybooks.inventoryappfaithsheppard.data.model.LoggedInUser;
import com.zybooks.inventoryappfaithsheppard.ui.login.UserDao;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class LoginDataSource {

    private UserDao userDao;

    public LoginDataSource(Context context) {
        userDao = new UserDao(context);
    }

    public Result<LoggedInUser> login(String username, String password) {
        try {
            String passwordHash = hashPassword(password);

            if (userDao.checkUserCredentials(username, passwordHash)) {
                // User authenticated successfully
                LoggedInUser user = new LoggedInUser(UUID.randomUUID().toString(), username);
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new IOException("Invalid username or password"));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public Result<LoggedInUser> register(String username, String password) {
        try {
            if (userDao.userExists(username)) {
                return new Result.Error(new IOException("User already exists"));
            }

            String passwordHash = hashPassword(password);
            boolean created = userDao.registerUser(username, passwordHash);

            if (created) {
                LoggedInUser user = new LoggedInUser(UUID.randomUUID().toString(), username);
                return new Result.Success<>(user);
            } else {
                return new Result.Error(new IOException("Failed to register user"));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering user", e));
        }
    }


    // Simple SHA-256 password hashing
    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = digest.digest(password.getBytes());

        // Convert to hex string
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
