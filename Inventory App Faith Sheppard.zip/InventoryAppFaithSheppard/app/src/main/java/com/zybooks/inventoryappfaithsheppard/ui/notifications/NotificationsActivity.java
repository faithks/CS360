package com.zybooks.inventoryappfaithsheppard.ui.notifications;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryappfaithsheppard.R;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryDbHelper;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryItem;

import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    private Button sendSmsButton;
    private Button returnButton;
    private RecyclerView recyclerView;
    private NotificationAdapter adapter;

    private InventoryDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        sendSmsButton = findViewById(R.id.sendSmsButton);
        returnButton = findViewById(R.id.returnButton);
        recyclerView = findViewById(R.id.recyclerViewNotifications);

        dbHelper = new InventoryDbHelper(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadLowInventoryItems();

        updateSmsButtonState();

        sendSmsButton.setOnClickListener(v -> requestSmsPermission());

        returnButton.setOnClickListener(v -> finish());
    }

    private void loadLowInventoryItems() {
        List<InventoryItem> lowItems = dbHelper.getLowInventoryItems();
        adapter = new NotificationAdapter(lowItems);
        recyclerView.setAdapter(adapter);
    }

    private void updateSmsButtonState() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendSmsButton.setText(R.string.sms_permission_granted);
            sendSmsButton.setEnabled(false);
        } else {
            sendSmsButton.setVisibility(View.VISIBLE);
            sendSmsButton.setText(R.string.grant_sms_permission);
            sendSmsButton.setEnabled(true);
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                updateSmsButtonState();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
                updateSmsButtonState();
            }
        }
    }
}
