package com.zybooks.inventoryappfaithsheppard.ui.inventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventoryappfaithsheppard.R;

public class EditInventoryActivity extends AppCompatActivity {

    private EditText editName, editQuantity, editDescription;
    private Button saveButton, returnButton;

    private InventoryDbHelper dbHelper;
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private InventoryItem pendingSmsItem;  // Store item awaiting SMS send after permission

    private int currentItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_inventory);

        dbHelper = new InventoryDbHelper(this);

        editName = findViewById(R.id.edit_item_name);
        editQuantity = findViewById(R.id.edit_item_quantity);
        editDescription = findViewById(R.id.edit_item_description);

        saveButton = findViewById(R.id.Savebutton);
        returnButton = findViewById(R.id.returnButton);

        // Check if editing existing item by retrieving passed ID from Intent
        currentItemId = getIntent().getIntExtra("item_id", -1);
        if (currentItemId != -1) {
            loadItemForEditing(currentItemId);
        }

        saveButton.setOnClickListener(v -> saveItem());
        returnButton.setOnClickListener(v -> finish());
    }

    private void loadItemForEditing(int itemId) {
        InventoryItem item = dbHelper.getItemById(itemId);
        if (item != null) {
            editName.setText(item.getName());
            editQuantity.setText(String.valueOf(item.getQuantity()));
            editDescription.setText(item.getDescription());
        }
    }

    private void saveItem() {
        String name = editName.getText().toString().trim();
        String quantityStr = editQuantity.getText().toString().trim();
        String description = editDescription.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            editName.setError("Item name is required");
            return;
        }
        if (TextUtils.isEmpty(quantityStr)) {
            editQuantity.setError("Quantity is required");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            editQuantity.setError("Quantity must be a number");
            return;
        }

        String alert = quantity < 5 ? "LOW" : "";

        InventoryItem oldItem = null;
        if (currentItemId != -1) {
            oldItem = dbHelper.getItemById(currentItemId);
        } else {
            // If new item, check if an item with same name exists for alert logic
            oldItem = dbHelper.getItemByName(name);
        }

        long id;
        InventoryItem newItem;

        if (currentItemId == -1) {
            // Adding new item
            id = dbHelper.addItem(new InventoryItem(0, name, quantity, alert, description));
            newItem = new InventoryItem((int) id, name, quantity, alert, description);
        } else {
            // Updating existing item
            id = dbHelper.updateItem(currentItemId, name, quantity, alert, description);
            newItem = new InventoryItem(currentItemId, name, quantity, alert, description);
        }

        if (id > 0) {
            Toast.makeText(this, "Item saved", Toast.LENGTH_SHORT).show();

            // Send SMS alert only if item just became low (quantity dropped below 5)
            if (oldItem == null || (oldItem.getQuantity() >= 5 && newItem.getQuantity() < 5)) {
                sendOrRequestSmsAlert(newItem);
            }

            finish();
        } else {
            Toast.makeText(this, "Error saving item", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendOrRequestSmsAlert(InventoryItem item) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSmsAlert(item);
        } else {
            // Save item so SMS can be sent after permission granted
            pendingSmsItem = item;
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void sendSmsAlert(InventoryItem item) {
        String phoneNumber = "1234567890";  // TODO: Change to target number or user preference
        String message = "Alert: Inventory item '" + item.getName() + "' is low (Qty: " + item.getQuantity() + ")";

        try {
            android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS alert.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();

                // Send SMS for pending item after permission granted
                if (pendingSmsItem != null) {
                    sendSmsAlert(pendingSmsItem);
                    pendingSmsItem = null;
                }
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
                pendingSmsItem = null;
            }
        }
    }
}
