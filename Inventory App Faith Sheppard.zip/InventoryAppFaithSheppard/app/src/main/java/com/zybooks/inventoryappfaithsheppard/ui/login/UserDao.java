package com.zybooks.inventoryappfaithsheppard.ui.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDao {

    private LoginDbHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new LoginDbHelper(context);
    }

    // Register a new user
    public boolean registerUser(String username, String passwordHash) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginDbHelper.COLUMN_USERNAME, username);
        values.put(LoginDbHelper.COLUMN_PASSWORD_HASH, passwordHash);

        long newRowId = db.insert(LoginDbHelper.TABLE_USERS, null, values);
        db.close();

        return newRowId != -1;  // Returns true if insert succeeded
    }

    // Check if username exists in the database
    public boolean userExists(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] columns = { LoginDbHelper.COLUMN_ID };
        String selection = LoginDbHelper.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = { username };

        Cursor cursor = db.query(LoginDbHelper.TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);

        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();

        return exists;
    }

    // Verify username and password hash for login
    public boolean checkUserCredentials(String username, String passwordHash) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] columns = { LoginDbHelper.COLUMN_ID };
        String selection = LoginDbHelper.COLUMN_USERNAME + " = ? AND " +
                LoginDbHelper.COLUMN_PASSWORD_HASH + " = ?";
        String[] selectionArgs = { username, passwordHash };

        Cursor cursor = db.query(LoginDbHelper.TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);

        boolean valid = cursor.moveToFirst();
        cursor.close();
        db.close();

        return valid;
    }
}
