package com.zybooks.inventoryappfaithsheppard.ui.database;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zybooks.inventoryappfaithsheppard.R;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.EditInventoryActivity;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryAdapter;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryDbHelper;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryItem;
import com.zybooks.inventoryappfaithsheppard.ui.notifications.NotificationsActivity;

import java.util.List;

public class DatabaseActivity extends AppCompatActivity {

    private InventoryDbHelper dbHelper;
    private InventoryAdapter adapter;
    private RecyclerView recyclerView;
    private List<InventoryItem> inventoryList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        dbHelper = new InventoryDbHelper(this);

        recyclerView = findViewById(R.id.inventory_grid);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        inventoryList = dbHelper.getAllItems();

        adapter = new InventoryAdapter(inventoryList, position -> {
            // Delete item from database
            InventoryItem item = inventoryList.get(position);
            dbHelper.deleteItem(item.getId());
            refreshData();
        });

        recyclerView.setAdapter(adapter);

        FloatingActionButton addFab = findViewById(R.id.floatingActionButton);
        addFab.setOnClickListener(v -> {
            Intent intent = new Intent(DatabaseActivity.this, EditInventoryActivity.class);
            startActivity(intent);
        });

        FloatingActionButton alertsFab = findViewById(R.id.floatingActionButton2);
        alertsFab.setOnClickListener(v -> {
            Intent intent = new Intent(DatabaseActivity.this, NotificationsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshData();
    }

    private void refreshData() {
        inventoryList = dbHelper.getAllItems();
        adapter.updateList(inventoryList);
    }
}
