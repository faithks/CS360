package com.zybooks.inventoryappfaithsheppard.ui.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class InventoryDbHelper extends SQLiteOpenHelper {

    // Database info
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Table name
    public static final String TABLE_NAME = "inventory_items";

    // Columns
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_ALERT = "alert"; // e.g., "LOW", "OK"
    public static final String COLUMN_DESCRIPTION = "description";

    // SQL to create table
    private static final String CREATE_TABLE_SQL = "CREATE TABLE " + TABLE_NAME + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_NAME + " TEXT NOT NULL," +
            COLUMN_QUANTITY + " INTEGER NOT NULL," +
            COLUMN_ALERT + " TEXT," +
            COLUMN_DESCRIPTION + " TEXT" +
            ");";

    public InventoryDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the inventory_items table
        db.execSQL(CREATE_TABLE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old table and recreate if database version changes (for now)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert a new inventory item
    public long insertItem(String name, int quantity, String alert, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_ALERT, alert);
        values.put(COLUMN_DESCRIPTION, description);

        long id = db.insert(TABLE_NAME, null, values);
        db.close();
        return id;
    }

    // Get all inventory items
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                null, // all columns
                null, // no selection
                null, // no selection args
                null,
                null,
                COLUMN_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
                String alert = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));

                InventoryItem item = new InventoryItem(id, name, quantity, alert, description);
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return items;
    }

    // Add a new item
    public long addItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_ALERT, item.getAlert());
        values.put(COLUMN_DESCRIPTION, item.getDescription());

        long id = db.insert(TABLE_NAME, null, values);
        db.close();
        return id;
    }

    // Update an existing item
    public int updateItem(int id, String name, int quantity, String alert, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_ALERT, alert);
        values.put(COLUMN_DESCRIPTION, description);

        int rows = db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    // Delete an item by ID
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    // Get all low inventory items (quantity < 5)
    public List<InventoryItem> getLowInventoryItems() {
        List<InventoryItem> lowItems = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                null,
                COLUMN_QUANTITY + "<?",
                new String[]{"5"},
                null,
                null,
                COLUMN_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
                String alert = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));

                InventoryItem item = new InventoryItem(id, name, quantity, alert, description);
                lowItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return lowItems;
    }

    // Get an inventory item by name
    public InventoryItem getItemByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_NAME + " = ?";
        String[] selectionArgs = { name };

        Cursor cursor = db.query(TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null);

        InventoryItem item = null;

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
            String alert = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));

            item = new InventoryItem(id, itemName, quantity, alert, description);
        }
        cursor.close();
        db.close();
        return item;
    }

    public InventoryItem getItemById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null);

        InventoryItem item = null;
        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
            String alert = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ALERT));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION));

            item = new InventoryItem(id, name, quantity, alert, description);
        }
        cursor.close();
        return item;
    }

}
