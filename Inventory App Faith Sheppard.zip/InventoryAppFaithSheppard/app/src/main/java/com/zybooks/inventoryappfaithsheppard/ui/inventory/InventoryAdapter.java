package com.zybooks.inventoryappfaithsheppard.ui.inventory;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryappfaithsheppard.R;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<InventoryItem> inventoryList;
    private OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    public InventoryAdapter(List<InventoryItem> inventoryList, OnDeleteClickListener listener) {
        this.inventoryList = inventoryList;
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = inventoryList.get(position);
        holder.textItemName.setText(item.getName());
        holder.textQuantity.setText(String.valueOf(item.getQuantity()));
        holder.textAlert.setText(item.getAlert());
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    public void updateList(List<InventoryItem> newList) {
        inventoryList = newList;
        notifyDataSetChanged();
    }

    class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName, textQuantity, textAlert;
        ImageButton buttonDelete;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            textAlert = itemView.findViewById(R.id.textAlert);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);

            buttonDelete.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (deleteClickListener != null && position != RecyclerView.NO_POSITION) {
                    deleteClickListener.onDeleteClick(position);
                }
            });

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    InventoryItem clickedItem = inventoryList.get(position);
                    Intent intent = new Intent(itemView.getContext(), EditInventoryActivity.class);
                    intent.putExtra("item_id", clickedItem.getId());
                    itemView.getContext().startActivity(intent);
                }
            });
        }
    }
}
