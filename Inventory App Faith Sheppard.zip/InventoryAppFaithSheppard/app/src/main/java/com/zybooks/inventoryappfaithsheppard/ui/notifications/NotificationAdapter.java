package com.zybooks.inventoryappfaithsheppard.ui.notifications;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryappfaithsheppard.R;
import com.zybooks.inventoryappfaithsheppard.ui.inventory.InventoryItem;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private final List<InventoryItem> lowInventoryList;

    public NotificationAdapter(List<InventoryItem> list) {
        this.lowInventoryList = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQty, itemAlert;
        ImageButton buttonDelete;   // ADD THIS

        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.textItemName);
            itemQty = itemView.findViewById(R.id.textQuantity);
            itemAlert = itemView.findViewById(R.id.textAlert);
            buttonDelete = itemView.findViewById(R.id.buttonDelete); // ADD THIS
        }
    }


    @NonNull
    @Override
    public NotificationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationAdapter.ViewHolder holder, int position) {
        InventoryItem item = lowInventoryList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQty.setText(String.valueOf(item.getQuantity()));
        holder.itemAlert.setText(item.getAlert());
        holder.buttonDelete.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return lowInventoryList.size();
    }
}
