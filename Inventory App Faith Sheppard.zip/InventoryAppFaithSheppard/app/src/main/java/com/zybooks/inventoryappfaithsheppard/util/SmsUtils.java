package com.zybooks.inventoryappfaithsheppard.util;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsUtils {

    public static final int SMS_PERMISSION_REQUEST_CODE = 123;

    // Request permission if not granted
    public static void requestSmsPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity,
                    new String[]{android.Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    // Check permission status
    public static boolean isSmsPermissionGranted(Context context) {
        return ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Send SMS if allowed
    public static void sendSms(Context context, String phoneNumber, String message) {
        if (isSmsPermissionGranted(context)) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(context, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(context, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(context, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
}
